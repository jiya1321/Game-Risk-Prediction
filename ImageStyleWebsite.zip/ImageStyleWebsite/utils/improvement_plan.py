from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from datetime import datetime
import os

def generate_improvement_plan(assessment, weekly_logs, trend):
    risk_level = assessment.risk_level
    gaming_hours = assessment.gaming_hours
    sleep_hours = assessment.sleep_hours
    
    avg_gaming = gaming_hours
    avg_sleep = sleep_hours
    avg_study = 0
    
    if weekly_logs:
        avg_gaming = sum(log.gaming_hours for log in weekly_logs) / len(weekly_logs)
        avg_sleep = sum(log.sleep_hours for log in weekly_logs) / len(weekly_logs)
        avg_study = sum(log.study_hours for log in weekly_logs) / len(weekly_logs)
    
    plan = f"""# Personalized Gaming Wellness Improvement Plan

## Current Status
- **Risk Level**: {risk_level}
- **Trend**: {trend.upper()}
- **Average Gaming Hours**: {avg_gaming:.1f} hours/day
- **Average Sleep**: {avg_sleep:.1f} hours/night
- **Average Study Time**: {avg_study:.1f} hours/day

"""
    
    if risk_level == "High Risk":
        plan += """## Immediate Actions Required

### Week 1-2: Crisis Intervention
**Gaming Time Reduction**
- Reduce gaming to maximum 4 hours/day
- Set strict daily cutoff time (no gaming after 10 PM)
- Remove gaming apps from bedroom devices
- Use app timers to enforce limits

**Sleep Recovery**
- Target 8 hours of sleep minimum
- Establish bedtime routine (no screens 1 hour before bed)
- Wake up at consistent time daily

**Physical Activity**
- 30 minutes of outdoor activity daily
- Join a sports club or gym
- Schedule walks during usual gaming time

### Week 3-4: Building New Habits
**Gaming Time Reduction**
- Further reduce to 3 hours/day maximum
- Implement "gaming-free" weekdays (Mon, Wed, Fri)
- Replace with productive hobbies

**Academic/Work Focus**
- Minimum 3 hours focused study/work daily
- Use Pomodoro technique (25min work, 5min break)
- Set specific achievement goals weekly

**Social Reconnection**
- Schedule 2 in-person social activities weekly
- Join study groups or clubs
- Reconnect with friends outside gaming

### Week 5-8: Long-term Sustainability
**Gaming Time Reduction**
- Stabilize at 2 hours/day on weekends only
- Track gaming time in journal
- Reward yourself for meeting goals (non-gaming rewards)

**Wellness Routine**
- Maintain 8+ hours sleep consistently
- Exercise 4-5 days/week
- Practice mindfulness/meditation 10min daily

**Goal Setting**
- Set academic/career milestone goals
- Develop new skill (instrument, language, art)
- Plan future without gaming dependency
"""
    
    elif risk_level == "Moderate Risk":
        plan += """## Balanced Improvement Strategy

### Week 1-2: Awareness Building
**Gaming Time Management**
- Reduce gaming to 5 hours/day maximum
- Track all gaming sessions in diary
- Identify triggers for excessive gaming

**Sleep Optimization**
- Target 7-8 hours of sleep nightly
- Set consistent sleep schedule
- Avoid screens 30 minutes before bed

**Physical Activity**
- 20 minutes of exercise daily
- Try new outdoor activities
- Walk/bike instead of driving when possible

### Week 3-4: Habit Restructuring
**Gaming Time Management**
- Reduce to 3-4 hours/day
- Designate specific gaming hours
- Try "gaming-free" Mondays and Wednesdays

**Productivity Enhancement**
- Increase study/work time to 4 hours daily
- Use productivity apps to track time
- Set weekly achievement goals

**Social Balance**
- Plan 1-2 non-gaming social activities weekly
- Join interest-based groups
- Maintain regular contact with family/friends

### Week 5-8: Sustainable Balance
**Gaming Time Management**
- Maintain 2-3 hours/day limit
- Focus on quality over quantity in gaming
- Balance with other hobbies

**Wellness Maintenance**
- Continue regular sleep schedule
- Exercise 3-4 times/week
- Practice stress management techniques

**Personal Growth**
- Set long-term personal goals
- Develop new skills or hobbies
- Monitor progress weekly
"""
    
    else:
        plan += """## Preventive Wellness Strategy

### Week 1-2: Optimization
**Gaming Time Awareness**
- Maintain current healthy gaming levels
- Track gaming patterns to prevent increases
- Ensure gaming remains recreational, not compulsive

**Sleep Consistency**
- Continue 7-8 hours of quality sleep
- Maintain consistent sleep schedule
- Optimize sleep environment

**Active Lifestyle**
- Continue regular physical activity
- Try new sports or fitness activities
- Stay active 4-5 days/week

### Week 3-4: Enhancement
**Time Management**
- Balance gaming with other hobbies
- Explore new interests outside gaming
- Maintain productivity in work/studies

**Social Engagement**
- Maintain strong social connections
- Regular face-to-face interactions
- Join community activities

**Mental Wellness**
- Practice mindfulness or meditation
- Develop stress management skills
- Maintain positive mental health habits

### Week 5-8: Sustained Excellence
**Balanced Living**
- Continue current healthy gaming habits
- Monitor for any concerning changes
- Maintain diverse interests and activities

**Personal Development**
- Set and achieve personal goals
- Continue learning new skills
- Maintain overall life balance

**Health Monitoring**
- Regular self-assessment
- Track wellness metrics
- Adjust habits as needed
"""
    
    plan += f"""
## Additional Recommendations

### Professional Support
- Consider counseling if struggling with implementation
- Join support groups for gaming moderation
- Consult healthcare provider for sleep issues

### Technology Tools
- Use screen time limiting apps (Freedom, Cold Turkey)
- Enable parental controls if needed
- Use habit tracking apps (Habitica, Streaks)

### Accountability
- Share goals with trusted friend or family member
- Weekly check-ins with accountability partner
- Keep progress journal

### Emergency Resources
- National Gaming Addiction Hotline: Available 24/7
- Online support communities
- Campus counseling services (if student)

---
**Remember**: Change takes time. Be patient with yourself and celebrate small victories!

*Plan generated on: {datetime.now().strftime('%Y-%m-%d')}*
"""
    
    return plan

def export_plan_to_pdf(plan, username):
    os.makedirs('static/exports', exist_ok=True)
    pdf_path = f'static/exports/plan_{username}_{datetime.now().strftime("%Y%m%d")}.pdf'
    
    doc = SimpleDocTemplate(pdf_path, pagesize=letter,
                           rightMargin=72, leftMargin=72,
                           topMargin=72, bottomMargin=18)
    
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#ff007f'),
        spaceAfter=30,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=16,
        textColor=colors.HexColor('#00eaff'),
        spaceAfter=12,
        spaceBefore=12,
        fontName='Helvetica-Bold'
    )
    
    body_style = ParagraphStyle(
        'CustomBody',
        parent=styles['BodyText'],
        fontSize=11,
        textColor=colors.black,
        spaceAfter=12,
        alignment=TA_LEFT
    )
    
    story = []
    
    story.append(Paragraph("Gaming Wellness Improvement Plan", title_style))
    story.append(Spacer(1, 12))
    story.append(Paragraph(f"Personalized Plan for: {username}", body_style))
    story.append(Paragraph(f"Generated: {datetime.now().strftime('%B %d, %Y')}", body_style))
    story.append(Spacer(1, 20))
    
    lines = plan.plan_content.split('\n')
    
    for line in lines:
        if line.startswith('# '):
            continue
        elif line.startswith('## '):
            story.append(Spacer(1, 12))
            story.append(Paragraph(line.replace('## ', ''), heading_style))
        elif line.startswith('### '):
            story.append(Spacer(1, 8))
            story.append(Paragraph(line.replace('### ', ''), styles['Heading3']))
        elif line.startswith('**') and line.endswith('**'):
            story.append(Paragraph(f"<b>{line.replace('**', '')}</b>", body_style))
        elif line.startswith('- '):
            story.append(Paragraph(f"• {line[2:]}", body_style))
        elif line.strip():
            story.append(Paragraph(line, body_style))
        else:
            story.append(Spacer(1, 6))
    
    doc.build(story)
    
    return pdf_path
