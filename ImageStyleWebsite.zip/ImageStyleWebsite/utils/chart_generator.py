import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from datetime import datetime
import os

plt.style.use('dark_background')

def generate_risk_chart(assessments):
    if not assessments:
        return None
    
    dates = [a.created_at for a in reversed(assessments[-10:])]
    scores = [a.risk_score for a in reversed(assessments[-10:])]
    
    fig, ax = plt.subplots(figsize=(10, 5), facecolor='#0a0e27')
    ax.set_facecolor('#0a0e27')
    
    ax.plot(dates, scores, color='#00eaff', linewidth=2, marker='o', 
            markersize=8, markerfacecolor='#ff007f', markeredgecolor='#00eaff', 
            markeredgewidth=2, label='Risk Score')
    
    ax.fill_between(dates, scores, alpha=0.3, color='#00eaff')
    
    ax.set_xlabel('Date', fontsize=12, color='#00eaff', fontweight='bold')
    ax.set_ylabel('Risk Score (%)', fontsize=12, color='#00eaff', fontweight='bold')
    ax.set_title('Risk Score Over Time', fontsize=14, color='#ff007f', fontweight='bold', pad=20)
    
    ax.tick_params(colors='#00eaff', labelsize=10)
    ax.spines['bottom'].set_color('#00eaff')
    ax.spines['top'].set_color('#00eaff')
    ax.spines['left'].set_color('#00eaff')
    ax.spines['right'].set_color('#00eaff')
    
    ax.grid(True, alpha=0.2, color='#00eaff', linestyle='--')
    ax.legend(facecolor='#0a0e27', edgecolor='#00eaff', fontsize=10)
    
    plt.tight_layout()
    
    chart_path = 'static/images/risk_chart.png'
    os.makedirs('static/images', exist_ok=True)
    plt.savefig(chart_path, dpi=100, facecolor='#0a0e27', edgecolor='none')
    plt.close()
    
    return 'images/risk_chart.png'

def generate_gaming_sleep_chart(logs):
    if not logs:
        return None
    
    if hasattr(logs[0], 'week_start'):
        dates = [log.week_start for log in reversed(logs[-10:])]
        gaming_hours = [log.gaming_hours for log in reversed(logs[-10:])]
        sleep_hours = [log.sleep_hours for log in reversed(logs[-10:])]
    else:
        dates = [log.created_at for log in reversed(logs[-10:])]
        gaming_hours = [log.gaming_hours for log in reversed(logs[-10:])]
        sleep_hours = [log.sleep_hours for log in reversed(logs[-10:])]
    
    fig, ax = plt.subplots(figsize=(10, 5), facecolor='#0a0e27')
    ax.set_facecolor('#0a0e27')
    
    width = 0.35
    x = range(len(dates))
    
    bars1 = ax.bar([i - width/2 for i in x], gaming_hours, width, 
                    label='Gaming Hours', color='#ff007f', alpha=0.8, edgecolor='#ff007f', linewidth=2)
    bars2 = ax.bar([i + width/2 for i in x], sleep_hours, width, 
                    label='Sleep Hours', color='#00eaff', alpha=0.8, edgecolor='#00eaff', linewidth=2)
    
    ax.set_xlabel('Date', fontsize=12, color='#00eaff', fontweight='bold')
    ax.set_ylabel('Hours', fontsize=12, color='#00eaff', fontweight='bold')
    ax.set_title('Gaming vs Sleep Hours', fontsize=14, color='#ff007f', fontweight='bold', pad=20)
    ax.set_xticks(x)
    ax.set_xticklabels([d.strftime('%m/%d') if hasattr(d, 'strftime') else str(d)[:10] for d in dates], 
                        rotation=45, ha='right')
    
    ax.tick_params(colors='#00eaff', labelsize=10)
    ax.spines['bottom'].set_color('#00eaff')
    ax.spines['top'].set_color('#00eaff')
    ax.spines['left'].set_color('#00eaff')
    ax.spines['right'].set_color('#00eaff')
    
    ax.grid(True, alpha=0.2, color='#00eaff', linestyle='--', axis='y')
    ax.legend(facecolor='#0a0e27', edgecolor='#00eaff', fontsize=10)
    
    plt.tight_layout()
    
    chart_path = 'static/images/gaming_sleep_chart.png'
    plt.savefig(chart_path, dpi=100, facecolor='#0a0e27', edgecolor='none')
    plt.close()
    
    return 'images/gaming_sleep_chart.png'
